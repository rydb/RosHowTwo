Commands to run rviz project:

Build the project in order to ensure dependencies work:
	source install/setup.bash
	-. colcon build --symlink-install
	
To run project
	ros2 launch urdfpublisher launch.py


Initialize rviz
	ros2 run rviz2 rviz2 -d rviz/NewUrdf.rviz(make sure to save after editing in order to make sure rviz keeps these settings in the .rviz file)
	
	
Notes:

-. If ROS can't detect "ament_cmake", the project is bugged and the only way I know how to fix it is by copying project files to a new ROS project by hand.

-. Add new  things for display to listen to by clicking the "Add" button in the display panel to the bottom left

-. If rviz is throwing errors about the "map" or "world" link not exisitng, then rviz silently failed to load NewUrdf.rviz. 
